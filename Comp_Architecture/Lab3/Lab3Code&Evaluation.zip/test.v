`timescale 1ns / 1ps

module testcase;
    reg clk;
    reg rst;

    riscv_pipeline_top dut (
        .clk(clk),
        .rst(rst)
    );

    initial begin
        clk = 0;
        forever #10 clk = ~clk;
    end

    initial begin
        
        // reset first
        rst = 1;
        #20;
        rst = 0;

        // run for 2000ns
        #2000;

        $finish;
    end
    
    always @(posedge clk) begin
        if (rst == 0) begin
            $display("Time=%0t, PC=0x%h, Instruction=0x%h, ra=0x%h, t0=0x%h, t1=0x%h, t2=0x%h, t3=0x%h, t4=0x%h",
                     $time,
                     dut.pc_current,
                     dut.instruction,
                     dut.reg_file.regs[1], // ra (x1)
                     dut.reg_file.regs[5], // t0 (x5)
                     dut.reg_file.regs[6], // t1 (x6)
                     dut.reg_file.regs[7], // t2 (x7)
                     dut.reg_file.regs[28], // t3 (x28)
                     dut.reg_file.regs[29] // t4 (x29)
                    );
        end
    end
    
    // for debug
    // always @(posedge clk) begin
    //     if (rst == 0) begin
    //         $display("Time = %0t", $time);
    //         $display("IF : PC=0x%h, Instruction=0x%h", dut.pc_current, dut.instruction);
    //         $display("ID : PC=0x%h, Instr=0x%h, rs1_data=0x%h, rs2_data=0x%h",
    //                 dut.pc_if_id, dut.instr_if_id, dut.rs1_data_id, dut.rs2_data_id);
    //         $display("EX : PC=0x%h, ALU_Res=0x%h, RegWrite=%b, MemRW=%b%b, Branch=%b, Jump=%b",
    //                 dut.pc_id_ex, dut.alu_result_ex, dut.reg_write_id_ex, dut.mem_read_id_ex, dut.mem_write_id_ex,
    //                 dut.branch_id_ex, dut.jump_id_ex);
    //         $display("MEM: ALU_Res=0x%h, MemData=0x%h, Rd_Addr=x%d, RegWrite=%b",
    //                 dut.alu_result_ex_mem, dut.mem_read_data_mem, dut.rd_addr_ex_mem, dut.reg_write_ex_mem);
    //         $display("WB : WB_Data=0x%h, Rd_Addr=x%d, RegWrite=%b",
    //                 dut.write_back_data, dut.rd_addr_mem_wb, dut.reg_write_mem_wb);
    //         $display("REGS: ra(x1)=0x%h, t0(x5)=0x%h, t1(x6)=0x%h, t2(x7)=0x%h",
    //                 dut.reg_file.regs[1], dut.reg_file.regs[5], dut.reg_file.regs[6], dut.reg_file.regs[7]);
    //     end
    // end


endmodule